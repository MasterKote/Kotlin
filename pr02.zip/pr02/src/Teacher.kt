class Teacher(name: String, surname: String, var experience_year: Int): User(name, surname) {
    fun getQualification(): String {
        if (experience_year < 5)
            return "Начинающий преподаватель"
        else if (experience_year >= 5 && experience_year < 10)
            return "Опытный преподаватель"
        else
            return "Профессиональный преподаватель"
    }
}