open class User(val name: String, val surname: String) {
    fun getFullName(): String {
        return "Имя: $name Фамилия: $surname"
    }
}