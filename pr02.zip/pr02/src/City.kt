class City(var name: String, var population: Int) {
    fun getcityPopulation(): Int{
        return population
    }
}