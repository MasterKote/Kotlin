class Book(val title: String, val author: String, val pages: Int) {
    fun  getBookInfo(): String {
        return "Название: $title Автор: $author Количество страниц: $pages"
    }
}