fun main(){
    println("Задание 1")

    val myCity = City("Saint-Petersburg", 455343)
    val population = myCity.getcityPopulation()
    println("Население города ${myCity.name} = $population")

    println()

    println("Задание 2")

    val cars = arrayOf(
        Car("Toyota", "Camry", 2008),
        Car("Lada", "Vesta", 2025),
        Car("volkswagen", "Polo", 2025),
        Car("Tesla", "Model S", 2021),
        Car("Audi", "A8", 2020)
    )

    for (car in cars){
        val model = car.getcarModel()
        println("Марка: ${car.brand}, модель: $model, год выпуска: ${car.year}")
    }

    println()

    println("Задание 3")

    val myBook = Book("Война и мир", "Л.Н. Толстой", 1360)
    println(myBook.getBookInfo())

    println()

    println("Задание 4")

    val myTeacher = Teacher("Иван", "Иванович", 13)
    println(myTeacher.getFullName())
    println(myTeacher.getQualification())
}