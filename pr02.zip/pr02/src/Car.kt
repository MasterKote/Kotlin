class Car(val brand: String, val model: String, val year: Int) {
    fun getcarModel(): String {
        return model
    }
}