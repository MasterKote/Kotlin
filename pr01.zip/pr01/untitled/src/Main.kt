fun main() {
    //Задание 1
    //Даны два числа. Вывести произведение этих чисел

    println("Задание 1")

    val digit1 = zadanie1vvod("Введите первое число:")
    val digit2 = zadanie1vvod("Введите второе число:")

    println("Произведение чисел $digit1 и $digit2 = ${zadanie1(digit1, digit2)}")

    println("---------------------------------------------------------------------------")

    //Задание 2
    //Дана сумма зарплаты. Вывести сумму 15% премии.

    println("Задание 2")

    val zarplata = zadanie2vvod("Введите сумму зарплаты:")

    println("15% премии от з/п = ${zadanie2(zarplata)}")

    println("---------------------------------------------------------------------------")

    //Задание 3
    //Дан год рождения. Вывести возраст через 10 лет.

    println("Задание 3")

    val currentYear = 2026
    val DateOfBirth = zadanie3vvod("Введите год рождения:", currentYear)

    println("Возраст через 10 лет после рождения: ${zadanie3(DateOfBirth)}")

    println("---------------------------------------------------------------------------")

    //Задание 4
    //Дано количество подъездов, этажей и квартир на этаже. Вывести
    //номер квартиры, если известен номер подъезда и этажа.

    val podjezd = 4 //кол-во подъездов
    val etazi = 10 //кол-во этажей
    val kvartir = 4 // кол-во квартир на этаже

    println("Задание 4")

    val podjezduser = zadanie4vvod("Введите номер подъезда:", 1, podjezd)
    val etazuser = zadanie4vvod("Введите номер этажа:", 1, etazi)

    println("Номер нужной квартиры = ${zadanie4(podjezduser, etazuser, etazi, kvartir)}")
}

fun zadanie1(digit1: Int, digit2: Int): Int = digit1 * digit2

fun zadanie2(zarplata: Int): Int = zarplata * 15 / 100

fun zadanie3(DateOfBirth: Int): Int = 2026 - DateOfBirth + 10

fun zadanie4(podjezduser: Int, etazuser: Int, etazi: Int, kvartir: Int): Int =
    (podjezduser - 1) * etazi * kvartir + (etazuser - 1) * kvartir + 1

fun zadanie1vvod(prompt: String): Int {
    while (true) {
        println(prompt)
        try {
            return readln().toInt()
        } catch (e: Exception) {
            println("Ошибка: введено не число. Попробуйте снова.")
        }
    }
}

fun zadanie2vvod(prompt: String): Int {
    while (true) {
        println(prompt)
        try {
            val value = readln().toInt()
            if (value > 0) return value
            println("Ошибка: число должно быть положительным. Попробуйте снова.")
        } catch (e: Exception) {
            println("Ошибка: введено не число. Попробуйте снова.")
        }
    }
}

fun zadanie3vvod(prompt: String, currentYear: Int): Int {
    while (true) {
        println(prompt)
        try {
            val year = readln().toInt()
            if (year > 0 && year <= currentYear) return year
            println("Ошибка: год должен быть в диапазоне 1-$currentYear. Попробуйте снова.")
        } catch (e: Exception) {
            println("Ошибка: введено не число. Попробуйте снова.")
        }
    }
}

fun zadanie4vvod(prompt: String, min: Int, max: Int): Int {
    while (true) {
        println(prompt)
        try {
            val value = readln().toInt()
            if (value in min..max) return value
            println("Ошибка: значение должно быть в диапазоне от $min до $max. Попробуйте снова.")
        } catch (e: Exception) {
            println("Ошибка: введено не число. Попробуйте снова.")
        }
    }
}