fun main() {
    //Задание 1
    //Даны два числа. Вывести произведение этих чисел
    try {
        println("Введите первое число:")
        val digit1 = readln().toInt()
        println("Введите второе число:")
        val digit2 = readln().toInt()

        println("Произведение чисел $digit1 и $digit2 = ${digit1 * digit2}")
    }
    catch (e: Exception)
    {
        println(e.message)
    }

    //Задание 2
    //Дана сумма зарплаты. Вывести сумму 15% премии.
    try {
        println("Введите сумму зарплаты:")
        val zarplata = readln().toInt()
        if (zarplata <= 0)
        {
            println("Зарплата не может быть отрицательной или равна нулю!")
        }
        else
        {
            println("15% премии от з/п = ${zarplata / 100 * 15}")
        }
    }
    catch (e: Exception)
    {
        println(e.message)
    }

    //Задание 3
    //Дан год рождения. Вывести возраст через 10 лет.
    try {
        println("Введите год рождения:")
        val DateOfBirth = readln().toInt()
        if (DateOfBirth <= 0)
        {
            println("Год рождения не может быть отрицательным или нулевым!")
        }
        else
        {
            println("Возраст через 10 лет после рождения: ${2026 - DateOfBirth + 10}")
        }
    }
    catch (e: Exception)
    {
        println(e.message)
    }

    //Задание 4
    //Дано количество подъездов, этажей и квартир на этаже. Вывести
    //номер квартиры, если известен номер подъезда и этажа.
    try {
        val podjezd = 4 //кол-во подъездов
        val etazi = 10 //кол-во этажей
        val kvartir = 4 // кол-во квартир на этаже

        println("Введите номер подъезда:")
        val podjezduser = readln().toInt()
        println("Введите номер этажа:")
        val etazuser = readln().toInt()
        if (etazuser <= 0 || etazuser > etazi || podjezduser <= 0 || podjezduser > podjezd)
        {
            println("Введён неверный номер этажа или подъезда!")
        }
        else
        {
            val kvartira = (podjezduser - 1) * etazi * kvartir + (etazuser - 1) * kvartir + 1
            println("Номер нужной квартиры = $kvartira")
        }
    }
    catch (e: Exception)
    {
        println(e.message)
    }
}